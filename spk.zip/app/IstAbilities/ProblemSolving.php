<?php

namespace App\IstAbilities;

class ProblemSolving extends IstAbility
{
    protected function getGradePerimeters()
    {
        return [6.06, 10, 13.93];
    }
}
