<?php

namespace App\IstAbilities;

class Spatial extends IstAbility
{
    protected function getGradePerimeters()
    {
        return [6.06, 10, 13.93];
    }
}