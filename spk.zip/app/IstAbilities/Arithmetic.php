<?php

namespace App\IstAbilities;

class Arithmetic extends IstAbility
{
    protected function getGradePerimeters()
    {
        return [3.9, 6.66, 9.42];
    }
}