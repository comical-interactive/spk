<?php

namespace App\IstAbilities;

class Logic extends IstAbility
{
    protected function getGradePerimeters()
    {
        return [4.77, 7.47, 10.18];
    }
}