<?php

namespace App\IstAbilities;

class Concentration extends IstAbility
{
    protected function getGradePerimeters()
    {
        return [10.43, 15.5, 20.66];
    }
}