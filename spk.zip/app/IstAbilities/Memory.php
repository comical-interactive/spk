<?php

namespace App\IstAbilities;

class Memory extends IstAbility
{
    protected function getGradePerimeters()
    {
        return [10.34, 15.5, 20.66];
    }
}