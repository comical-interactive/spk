<?php

namespace App\IstAbilities;

class Verbal extends IstAbility
{
    protected function getGradePerimeters()
    {
        return [7.8, 10.6, 13.41];
    }
}