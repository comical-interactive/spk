<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laporan LS</title>

    <style>
        @font-face {
            font-family: OpenSans-Regular;
            src: url('https://fonts.googleapis.com/css?family=Open+Sans');
        }

        html {
            font-family: 'Open Sans', sans-serif;
        }

        body {
            padding: 0 40px;
        }

        .page-break {
            page-break-after: always;
        }

        h2, h3 {
            text-align: center !important
        }

        h3 {
            margin-top: 3rem !important;
            background-color: lightgrey;
            padding: 20px;
        }

        div > h4 {
            color: maroon
        }

        img {
            width: 300px;
            margin-top: 10px;
            border: 1px solid maroon
        }
    </style>
</head>
<body>
    <?php $__currentLoopData = $school->mbtiEppsLss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <section>
            <h2 class="text-center">GAYA BELAJAR</h2>

            <?php echo $__env->make("pdfs.partials.ls-{$model->ls}", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            
            <center>
                <img src="<?php echo e(asset('img/ls.jpg')); ?>">   
            </center>

            <?php if(! $loop->last): ?>
                <div class="page-break"></div>
            <?php endif; ?>
        </section>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>