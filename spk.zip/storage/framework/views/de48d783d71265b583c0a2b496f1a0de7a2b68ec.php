<?php $__env->startSection('page-title'); ?>
Intelligenz Struktur Test
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="col-12">
    <div class="card">
      <div class="header">
        <h4 class="title">IST</h4>
        <p class="category"><?php echo e($school->name); ?></p>
      </div>

      <div class="content">
        <div class="table-responsive table-full-width">
          <table class="table table-striped">
            <tbody>
              <?php for($i = 1; $i <= $partCount; $i++): ?>
                <tr>
                  <td>
                    <a href="<?php echo e(route('school-ists.download', ['school' => $school, 'part' => $i])); ?>">
                      Download Laporan IST part <?php echo e($i); ?>

                    </a>      
                  </td>
                </tr>                  
              <?php endfor; ?>            
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>