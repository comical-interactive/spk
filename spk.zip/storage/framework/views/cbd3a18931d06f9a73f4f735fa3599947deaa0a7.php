<?php if(request()->has('take')): ?>
    <?php echo e($schools->appends(['take' => request('take')])->render()); ?>

<?php else: ?>
    <?php echo e($schools->links()); ?>

<?php endif; ?>