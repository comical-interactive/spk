<?php $__env->startSection('page-title'); ?>
Data Siswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-xs-12">
  <div class="card">
    <div class="header">
      <h4 class="title">Siswa</h4>
      <p class="category"><?php echo e($school->name); ?></p>
    </div>

    <div class="content">
      <?php if($students->count() > 0): ?>
        <div class="table-responsive">
          <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">Nomor Tes</th>
                <th scope="col">Nama</th>
                <th scope="col">Jenis Kelamin</th>
                <th scope="col">Umur</th>
                <th scope="col"></th>
              </tr>
            </thead>

            <tbody>
              <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($student->testNumber); ?></td>
                    <td><?php echo e($student->name); ?></td>
                    <td><?php echo e($student->sex); ?></td>
                    <td><?php echo e($student->age); ?></td>
                    <td>
                      <a href="<?php echo e(route('school-students.download', compact('school', 'student'))); ?>">
                        Download Laporan Tes
                      </a>
                    </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <p class="lead">Tidak ada data siswa</p>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>