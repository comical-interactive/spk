<?php $__env->startSection('page-title'); ?>
Myers–Briggs Type Indicator, Edward Personal Preference Schedule, Learning Style
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-xs-12">
  <div class="card">
    <div class="header">
      <div class="row">
        <div class="col-md-6">
          <h4 class="title">MBTI EPPS LS</h4>
          <p class="category"><?php echo e($school->name); ?></p>
        </div>

        <div class="col-md-6 text-right">
          <a href="<?php echo e(route('school-mels.download', ['school' => $school, 'test' => 'mbti'])); ?>" class="btn btn-info btn-fill">
            Download Laporan MBTI
          </a>

          <a href="<?php echo e(route('school-mels.download', ['school' => $school, 'test' => 'epps'])); ?>" class="btn btn-info btn-fill">
            Download Laporan EPPS
          </a>

          <a href="<?php echo e(route('school-mels.download', ['school' => $school, 'test' => 'ls'])); ?>" class="btn btn-info btn-fill">
            Download Laporan LS
          </a>
        </div>
      </div>
    </div>

    <div class="content">
      <?php if($mbtiEppsLss->count() > 0): ?>
      <div class="table-responsive">
        <table class="table table-striped">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Nomor Tes</th>
              <th scope="col">Nama</th>
              <th scope="col">Umur</th>
              <th scope="col">Jenis Kelamin</th>
            </tr>
          </thead>

          <tbody>
            <?php $__currentLoopData = $mbtiEppsLss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($model->test_taker_index); ?></td>
                <td><?php echo e($model->test_taker_number); ?></td>
                <td><?php echo e($model->test_taker_name); ?></td>
                <td><?php echo e($model->test_taker_age); ?></td>
                <td><?php echo e($model->test_taker_sex); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <?php else: ?>
        <p class="lead">Tidak ada data siswa</p>
      <?php endif; ?>

      <?php echo e($mbtiEppsLss->links()); ?>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>