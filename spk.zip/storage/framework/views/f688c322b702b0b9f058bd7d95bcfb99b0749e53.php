<?php $__env->startSection('page-title'); ?>
Direktori <?php echo e($school->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="card">
            <div class="header">
                <div class="row">
                    <div class="col-md-6">
                        <h4 class="title"><?php echo e($school->name); ?></h4>
                    </div>

                    <div class="col-md-6 text-right">
                        <ul class="list-inline">
                            <li>
                                <form method="POST" action="<?php echo e(route('schools.reset', compact('school'))); ?>">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>

                                    <button class="btn btn-success btn-fill btn-wd">
                                        <i class="ti-reload"></i> Reset Data
                                    </button>
                                </form>
                            </li>

                            <li>
                                <form method="POST" action="<?php echo e(route('schools.destroy', compact('school'))); ?>">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>

                                    <button class="btn btn-danger btn-fill btn-wd">
                                        <i class="ti-trash"></i> Hapus Sekolah
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="content h-500">
                <form
                    class="form form-import"
                    action="<?php echo e(route('school-ists.import', compact('school'))); ?>"
                    method="POST"
                    enctype="multipart/form-data"
                >
                    <?php echo csrf_field(); ?>

                    <h4>Impor Data IST</h4>

                    <div class="form-inline">
                        <div class="form-group">
                            <input type="file" class="form-control border-input" name="file">
                        </div>

                        <button class="btn btn-primary btn-fill">Upload</button>
                    </div>

                    <?php if($school->ists_count > 0): ?>
                        <p class="text-success">Data IST telah diimpor, mengupload data baru akan menghapus data yang
                        lama</p>
                    <?php endif; ?>
                </form>

                <form
                    class="form form-import"
                    action="<?php echo e(route('school-rmibs.import', compact('school'))); ?>"
                    method="POST"
                    enctype="multipart/form-data"
                >
                    <?php echo csrf_field(); ?>

                    <h4>Impor Data RMIB</h4>

                    <div class="form-inline">
                        <div class="form-group">
                            <input type="file" class="form-control border-input" name="file">
                        </div>

                        <button class="btn btn-primary btn-fill">Upload</button>
                    </div>

                    <?php if($school->rmibs_count > 0): ?>
                        <p class="text-success">Data RMIB telah diimpor, mengupload data baru akan menghapus data yang
                        lama</p>
                    <?php endif; ?>
                </form>

                <form
                    class="form form-import"
                    action="<?php echo e(route('school-mels.import', compact('school'))); ?>"
                    method="POST"
                    enctype="multipart/form-data"
                >
                    <?php echo csrf_field(); ?>

                    <h4>Impor Data MBTI EPPS LS</h4>

                    <div class="form-inline">
                        <div class="form-group">
                            <input type="file" class="form-control border-input" name="file">
                        </div>

                        <button class="btn btn-primary btn-fill">Upload</button>
                    </div>

                    <?php if($school->mbti_epps_lss_count > 0): ?>
                        <p class="text-success">Data MBTI EPPS LS telah diimpor, mengupload data baru akan menghapus
                        data yang lama</p>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>