<?php $__env->startSection('page-title'); ?>
Rothwell Miller Interest Blank
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-xs-12">
  <div class="card">
    <div class="header">
      <div class="row">
        <div class="col-md-6">
          <h4 class="title">RMIB</h4>
          <p class="category"><?php echo e($school->name); ?></p>
        </div>

        <div class="col-md-6 text-right">
          <ul class="list-inline">
            <li>
              <form action="<?php echo e(route('school-rmibs.import-ist-recap', compact('school'))); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="input-group">
                  <input type="file" name="file">

                  <span class="input-group-btn">
                    <button class="btn btn-primary btn-fill" type="submit">Upload</button>
                  </span>
                </div>
              </form>
            </li>

            <li>
              <a href="<?php echo e(route('school-rmibs.download', compact('school'))); ?>" class="btn btn-info btn-fill">
                Download Laporan RMIB
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>

    <div class="content">
      <?php if($rmibs->count() > 0): ?>
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th scope="col" rowspan="2">#</th>
                <th scope="col" rowspan="2" style="min-width: 300px">Nama</th>
                <th scope="col" colspan="12">Peringkat Minat</th>
              </tr>

              <tr>
                <th scope="col" nowrap>OUT</th>
                <th scope="col" nowrap>MECH</th>
                <th scope="col" nowrap>COMP</th>
                <th scope="col" nowrap>SCIE</th>
                <th scope="col" nowrap>PERS</th>
                <th scope="col" nowrap>AEST</th>
                <th scope="col" nowrap>MUS</th>
                <th scope="col" nowrap>LITE</th>
                <th scope="col" nowrap>SOC</th>
                <th scope="col" nowrap>CLER</th>
                <th scope="col" nowrap>PRAC</th>
                <th scope="col" nowrap>MED</th>
              </tr>
            </thead>

            <tbody>
              <?php $__currentLoopData = $rmibs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rmib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($rmib->test_taker_index); ?></td>
                  <td><?php echo e($rmib->test_taker_name); ?></td>

                  <?php if($rmib->ranks): ?>
                    <?php $__currentLoopData = $rmib->ranks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <td class="text-center"><?php echo e($rank); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <td colspan="12">Gagal memuat peringkat minat</td>
                  <?php endif; ?>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <p class="lead">Tidak ada data siswa</p>
      <?php endif; ?>

      <?php echo e($rmibs->links()); ?>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
<style>
  table.table th {
    text-align: center;
    font-weight: 800 !important
  }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>