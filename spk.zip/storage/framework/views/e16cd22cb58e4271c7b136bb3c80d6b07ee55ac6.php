<td class="text-center">
    <?php if($grade == 'SK'): ?>
      <img src="<?php echo e(asset('img/checkmark.png')); ?>" height="15">
    <?php endif; ?>
  </td>

  <td class="text-center">
    <?php if($grade == 'K'): ?>
      <img src="<?php echo e(asset('img/checkmark.png')); ?>" height="15">
    <?php endif; ?>
  </td>

  <td class="text-center">
    <?php if($grade == 'S'): ?>
      <img src="<?php echo e(asset('img/checkmark.png')); ?>" height="15">
    <?php endif; ?>
  </td>

  <td class="text-center">
    <?php if($grade == 'B'): ?>
      <img src="<?php echo e(asset('img/checkmark.png')); ?>" height="15">
    <?php endif; ?>
  </td>

  <td class="text-center">
    <?php if($grade == 'SB'): ?>
      <img src="<?php echo e(asset('img/checkmark.png')); ?>" height="15">
    <?php endif; ?>
  </td>
