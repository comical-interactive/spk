<?php $__env->startSection('page-title'); ?>
Data Sekolah
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-xs-12">
    <div class="card">
      <div class="header">
        <div class="row">
          <div class="col-sm-8">
            <h4 class="title">Data Sekolah</h4>
            <p class="subtitle">List daftar sekolah yang terdaftar</p>
          </div>

          <div class="col-sm-4 text-right">
            <a href="<?php echo e(route('schools.create')); ?>" class="btn btn-primary btn-fill">
              <i class="ti-plus"></i> Tambah Sekolah
            </a>
          </div>
        </div>
      </div>

      <div class="content">
        <?php if($schools->count() > 0): ?>
          <div class="table-responsive table-full-width">
            <table class="table table-striped">
              <thead>
                <th>#</th>
                <th>Nama Sekolah</th>
                <th>Alamat</th>
                <th>Kabupaten</th>
              </thead>

              <tbody>
                <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->index + 1); ?></td>
                    <td>
                      <a href="<?php echo e(route('schools.show', [$school])); ?>"><?php echo e($school->name); ?></a>
                    </td>
                    <td><?php echo e($school->address); ?></td>
                    <td></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        <?php else: ?>
          <p class="lead">Tidak ada data sekolah</p>
        <?php endif; ?>

        <?php echo $__env->make('layouts.partials.school-pagination', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>