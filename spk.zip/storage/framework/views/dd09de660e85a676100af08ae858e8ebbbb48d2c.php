<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laporan MBTI</title>

    <style>
        @font-face {
            font-family: OpenSans-Regular;
            src: url('https://fonts.googleapis.com/css?family=Open+Sans');
        }

        html {
            font-family: 'Open Sans', sans-serif;
        }

        body {
            padding: 0 40px;
        }

        .page-break {
            page-break-after: always;
        }

        h3 {
            margin-top: 2rem;
        }

        table > tbody > tr > td:nth-child(3) {
            padding-left: 20px
        }

        table > tbody > tr > td:nth-child(odd) {
            font-weight: bold
        }

        h3 {
            color: maroon
        }

        ul > li {
            line-height: 1.5
        }
    </style>
</head>
<body>
    <?php $__currentLoopData = $school->mbtiEppsLss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <section>
            <div>
                <h4>Nomor Test: <?php echo e($model->test_taker_number); ?></h4>
                <h4>Nama: <?php echo e($model->test_taker_name); ?></h4>
            </div>

            <?php if($model->mbti->isValid()): ?>
                <div>
                    <h3>Tipe Kepribadian</h3>

                    <table>
                        <tr>
                            <td>Introvert</td>
                            <td>: <?php echo e($model->mbti->introvert); ?>%</td>
                            <td>Extrovert</td>
                            <td>: <?php echo e($model->mbti->extrovert); ?>%</td>
                        </tr>

                        <tr>
                            <td>Sensing</td>
                            <td>: <?php echo e($model->mbti->sensing); ?>%</td>
                            <td>Intuition</td>
                            <td>: <?php echo e($model->mbti->intuition); ?>%</td>
                        </tr>

                        <tr>
                            <td>Thinking</td>
                            <td>: <?php echo e($model->mbti->thinking); ?>%</td>
                            <td>Feeling</td>
                            <td>: <?php echo e($model->mbti->feeling); ?>%</td>
                        </tr>

                        <tr>
                            <td>Judging</td>
                            <td>: <?php echo e($model->mbti->judging); ?>%</td>
                            <td>Perceiving</td>
                            <td>: <?php echo e($model->mbti->perceiving); ?>%</td>
                        </tr>
                    </table>
                </div>

                <?php echo $__env->make("pdfs.partials.mbti-{$model->mbti->type}", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


            <?php else: ?>
                <h1>Hasil Tidak Valid</h1>
            <?php endif; ?>

        </section>

        <?php if(! $loop->last): ?>
            <div class="page-break"></div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>