<table>
    <thead></thead>
    <tbody>
      <?php $__currentLoopData = range(0, 5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr></tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <tr>
        <td colspan="6" align="center">REKAP REKOMENDASI PSIKOTES PEMINATAN/PENJURUSAN SISWA BARU</td>
      </tr>

      <tr>
        <td colspan="6"><?php echo e(strtoupper($school->name)); ?> TAHUN <?php echo e(date('Y')); ?></td>
      </tr>

      <tr></tr>

      <tr>
        <td>Nomor Urut</td>
        <td>Nama</td>
        <td>Nomor Tes</td>
        <td>IQ, menurut IST</td>
        <td>Rekomendasi 1</td>
        <td>Rekomendasi 1</td>
      </tr>

      <?php $__currentLoopData = $school->ists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($ist->test_taker_index); ?></td>
          <td><?php echo e($ist->test_taker_name); ?></td>
          <td><?php echo e($ist->test_taker_number); ?></td>
          <td><?php echo e($ist->iq->score()); ?></td>
          <td><?php echo e($ist->recommendation->first()); ?></td>
          <td><?php echo e($ist->recommendation->second()); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <tr></tr>

      <tr>
        <td>Keterangan:</td>
      </tr>

      <tr>
        <td>MIA</td>
        <td>Matematika dan Ilmu Alam</td>
      </tr>

      <tr>
        <td>IIS</td>
        <td>Ilmu Ilmu Sosial</td>
      </tr>

      <tr>
        <td>IBB</td>
        <td>Ilmu Bahasa dan Budaya</td>
      </tr>

      <tr></tr>
      <tr></tr>

      <tr>
        <td></td>
        <td></td>
        <td></td>
        <td colspan="3">Makassar, <?php echo e(\Carbon\Carbon::now()->format('d F Y')); ?></td>
      </tr>

      <tr>
        <td></td>
        <td></td>
        <td></td>
        <td colspan="3">Educare,</td>
      </tr>

      <tr></tr>
      <tr></tr>
      <tr></tr>

      <tr>
        <td></td>
        <td></td>
        <td></td>
        <td colspan="3">Harlina Hamid, S.Psi, M.Si, M.Psi, Psikolog</td>
      </tr>
    </tbody>
  </table>