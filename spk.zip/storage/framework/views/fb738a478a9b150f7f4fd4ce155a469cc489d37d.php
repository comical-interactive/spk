<?php if($schools->count() <= 0): ?>
  <h2>Tambahkan data sekolah terlebih dahulu</h2>
<?php endif; ?>

<div class="row">
  <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-3 col-sm-6">
      <div class="card">
        <div class="content text-center">
          <h4><?php echo e($school->name); ?></h4>

          <div class="footer">
            <hr />
            <a href="<?php echo e(route($routeName, [$school])); ?>">
                <i class="ti-info-alt"></i> <?php echo e($footerText); ?>

            </a>
          </div>
        </div>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="row">
  <div class="col-xs-12">
    <?php echo $__env->make('layouts.partials.school-pagination', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</div>
