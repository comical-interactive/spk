<div class="col-12">
  <div class="card">
    <div class="header">
      <div class="row">
        <div class="col-md-6">
          <h4 class="title"><?php echo e($title); ?></h4>
          <p class="category"><?php echo e($school->name); ?></p>
        </div>

        <div class="col-md-6 text-right">
          <?php if($downloadable->count() > 0): ?>
            <a href="<?php echo e(route($routeName, [$school])); ?>" class="btn btn-info btn-fill">
              Download Keseluruhan
            </a>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <div class="content">
      <?php if($downloadable->count() > 0): ?>
        <div class="table-responsive table-full-width">
          <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col" style="min-width: 300px">Deskripsi</th>
                <th scope="col">Link</th>
              </tr>
            </thead>

            <tbody>
              <?php $__currentLoopData = $downloadable->chunk($downloadableCount); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($loop->index + 1); ?></td>

                  <td>
                    Download <?php echo e($title); ?> Nomor Urut <?php echo e($chunk->first()); ?> sampai <?php echo e($chunk->last()); ?>

                  </td>

                  <td>
                    <a
                      href="<?php echo e(route($routeName, [$school])); ?>?offset=<?php echo e($chunk->first() - 1); ?>"
                      class="btn btn-info btn-fill"
                    >
                      Download
                    </a>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <p class="lead">Tidak ada data siswa</p>
      <?php endif; ?>
    </div>
  </div>
</div>