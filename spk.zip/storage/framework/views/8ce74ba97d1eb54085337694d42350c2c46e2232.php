<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Laporan EPPS</title>

  <?php echo $__env->make('layouts.partials.pdf-style', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
  <?php $__currentLoopData = $school->mbtiEppsLss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <section>
      <?php echo $__env->make('layouts.partials.pdf-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <h2 class="page-heading">PROFIL KEPRIBADIAN</h2>

      <table class="table table-bordered table-grade">
        <thead>
          <tr>
            <th>ASPEK</th>
            <th>GAMBARAN SKOR RENDAH</th>
            <th>SK</th>
            <th>K</th>
            <th>S</th>
            <th>B</th>
            <th>SB</th>
            <th>GAMBARAN SKOR TINGGI</th>
          </tr>
        </thead>

        <tbody>
          <tr>
            <td>KEPERCAYAAN DIRI</td>
            <td>Kurang mampu menunjukkan performa yang mengekspresikan kelebihan yang dimilikinya</td>
            <?php $__env->startComponent('components.ability-grade', ['grade' => $model->epps->ach_grade]); ?>
            <?php echo $__env->renderComponent(); ?>
            <td>Sangat mampu menunjukkan performa yang mengekspresikan kelebihan yang dimilikinya</td>
          </tr>

          <tr>
            <td>PENYESUAIAN DIRI</td>
            <td>Kurang mampu melakukan adaptasi dan menyatu dengan lingkungan yang baru & berbeda</td>
            <?php $__env->startComponent('components.ability-grade', ['grade' => $model->epps->ach_grade]); ?>
            <?php echo $__env->renderComponent(); ?>
            <td>Sangat mampu melakukan adaptasi dan menyatu dengan lingkungan yang baru & berbeda</td>
          </tr>

          <tr>
            <td>KESTABILAN EMOSI</td>
            <td>Kurang mampu mengelola emosinya jika dihadapkan pada stimulus dari lingkungan yang tidak sesuai dengan
            kondisi mereka/ bersifat menekan</td>
            <?php $__env->startComponent('components.ability-grade', ['grade' => $model->epps->ach_grade]); ?>
            <?php echo $__env->renderComponent(); ?>
            <td>Sangat mampu mengelola emosinya jika dihadapkan pada stimulus dari lingkungan yang tidak sesuai dengan
            kondisi mereka/ bersifat menekan</td>
          </tr>

          <tr>
            <td>TANGGUNG JAWAB/ KOMITMEN TERHADAP TUGAS</td>
            <td>Kurang menunjukkan komitmen yang kuat dan berbuat yang terbaik sampai selesai saat dihadapkan pada suatu
            tugas</td>
            <?php $__env->startComponent('components.ability-grade', ['grade' => $model->epps->ach_grade]); ?>
            <?php echo $__env->renderComponent(); ?>
            <td>Menunjukkan komitmen yang sangat kuat dan berbuat yang terbaik sampai selesai saat dihadapkan pada suatu
            tugas</td>
          </tr>
        </tbody>

        <tfoot>
          <tr style="text-align: center">
            <td colspan="8">Keterangan :  SK = Sangat Kurang, K = Kurang, S = Sedang, B = Baik, SB = Sangat Baik</td>
          </tr>
        </tfoot>
      </table>

      <?php if(! $loop->last): ?>
        <div class="page-break"></div>
      <?php endif; ?>
    </section>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>