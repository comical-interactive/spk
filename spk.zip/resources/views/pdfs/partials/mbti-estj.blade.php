<div>
    <h3>ESTJ (Konservatif 1 Disiplin)</h3>

    <ul>
        <li>Praktis, realistis, berpegang pada fakta, dengan dorongan alamiah untuk bisnis dan mekanistis.</li>
        <li>Sangat sistematis, procedural dan terencana.</li>
        <li>Disiplin, on time dan pekerja keras.</li>
        <li>Tidak tertarik pada subject yang tidak berguna baginya, tapi dapat menyesuaikan diri jika diperlukan.</li>
        <li>Senang mengorganisir sesuatu. Bisa menjadi administrator yang baik jika mereka ingat untuk memperhatikan perasaan dan perspektif orang lain.</li>
    </ul>
</div>

<div>
    <h3>Saran Pengembangan</h3>

    <ul>
        <li>Kurangi keinginan untuk mengontrol dan memaksa orang lain.</li>
        <li>Belajarlah untuk mengontrol emosi dan amarah Anda.</li>
        <li>Cobalah untuk introspeksi diri dan meluangkan waktu sejenak untuk merenung.</li>
        <li>Belajarlah untuk lebih sabar dan low profile</li>
        <li>Belajarlah untuk memahami orang lain.</li>
    </ul>
</div>

<div>
    <h3>Saran Profesi</h3>

    <p>Militer, Manajer, Polisi, Hakim, Pengacara, Guru, Sales, Auditor, Akuntan, System Analyst</p>
</div>
