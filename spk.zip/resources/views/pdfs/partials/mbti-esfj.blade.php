<div>
    <h3>ESFJ (Harmonis)</h3>

    <ul>
        <li>Hangat, banyak bicara, populer, dilahirkan untuk bekerjasama, suportif dan anggota kelompok yang aktif.</li>
        <li>Membutuhkan keseimbangan dan baik dalam menciptakan harmoni.</li>
        <li>Selalu melakukan sesuatu yang manis bagi orang lain. Kerja dengan baik dalam situasi yang mendukung dan memujinya.</li>
        <li>Santai, easy going, sederhana, tidak berfikir panjang.</li>
        <li>Teliti dan rajin merawat apa yang ia miliki.</li>
    </ul>
</div>

<div>
    <h3>Saran Pengembangan</h3>

    <ul>
        <li>Jangan mengorbankan diri hanya untuk menyenangkan orang lain.</li>
        <li>Jangan mengukur harga diri Anda dari perlakuan, penghargaan dan pujian orang lain.</li>
        <li>Mintalah pertimbangan orang lain dalam mengambil keputusan. Belajarlah untuk lebih tegas.</li>
        <li>Terima tanggungjawab hidup dan belajarlah untuk lebih dewasa. Jangan mengasihani diri sendiri.</li>
        <li>Hadapi kritik dan konflik, jangan lari.</li>
    </ul>
</div>

<div>
    <h3>Saran Profesi</h3>

    <p>Perencana Keuangan, Perawat, Guru, Bidang anak-anak, Konselor, Administratif, Hospitality</p>
</div>
