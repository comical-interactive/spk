<div>
    <h3>ENTP (Inovatif 1 Kreatif)</h3>

    <ul>
        <li>Gesit, kreatif, inovatif, cerdik, logis, baik dalam banyak hal.</li>
        <li>Banyak bicara dan punya kemampuan debat yang baik. Bisa berargumentasi untuk senang-senang saja tanpa merasa bersalah.</li>
        <li>Fleksibel. Punya banyak cara untuk memecahkan masalah dan tantangan.</li>
        <li>Kurang konsisten. Cenderung untuk melakukan hal baru yang menarik hati setelah melakukan sesuatu yang lain.</li>
        <li>Punya keinginan kuat untuk mengembangkan diri.</li>
    </ul>
</div>

<div>
    <h3>Saran Pengembangan</h3>

    <ul>
        <li>Cobalah untuk win-win solution. Jangan ingin menang sendiri.</li>
        <li>Belajarlah untuk disiplin dan konsisten.</li>
        <li>Hindari perdebatan tidak penting</li>
        <li>Belajarlah untuk sedikit waspada. Seimbangkan cara pandang Anda agar tidak terlalu optimis dan mengambil resiko yang tidak realistis.</li>
        <li>Belajarlah untuk memberi perhatian pada perasaan orang lain.</li>
    </ul>
</div>

<div>
    <h3>Saran Profesi</h3>

    <p>Pengacara, Psikolog, Konsultan, Ilmuwan, Aktor,Marketing, Programmer, Fotografer</p>
</div>
