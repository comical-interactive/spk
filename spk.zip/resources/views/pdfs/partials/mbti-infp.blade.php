<div>
    <h3>INFP (Idealis)</h3>

    <ul>
        <li>Sangat perhatian dan peka dengan perasaan orang lain.</li>
        <li>Penuh dengan antusiasme dan kesetiaan, tapi biasanya hanya untuk orang dekat.</li>
        <li>Peduli pada banyak hal. Cenderung mengambil terlalu banyak dan menyelesaikan sebagian.</li>
        <li>Cenderung idealis dan perfeksionis.</li>
        <li>Berpikir win-win solution, mempercayai dan mengoptimalkan orang lain.</li>
    </ul>
</div>

<div>
    <h3>Saran Pengembangan</h3>

    <ul>
        <li>Belajarlah menghadapi kritik. Jika baik maka kritik itu bisa membangun Anda, namun jika tidak abaikan saja.
        Jangan ragu pula untuk bertanya dan minta saran.</li>
        <li>Belajarlah untuk bersikap tegas. Jangan selalu berperasaan dan menyenangkan orang dengan tindakan baik.
        Bertindak baik itu berbeda dengan bertindak benar.</li>
        <li>Jangan terlalu menyalahkan diri dan bersikap terlalu keras pada diri sendiri. Kegagalan adalah hal biasa
        dan semua orang pernah mengalaminya.</li>
        <li>Jangan terlalu baik pada orang lain tapi melupakan diri sendiri. Anda juga punya tanggungjawab untuk
        berbuat baik pada diri sendiri.</li>
    </ul>
</div>

<div>
    <h3>Saran Profesi</h3>

    <p>Penulis, Sastrawan, Konselor, Psikolog, Pengajar, Seniman, Rohaniawan, Bidang Hospitality</p>
</div>
