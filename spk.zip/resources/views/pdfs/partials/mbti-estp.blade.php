<div>
    <h3>ESTP (Spontan)</h3>

    <ul>
        <li>Spontan, Aktif, Enerjik, Cekatan, Cepat, Sigap, Antusias, Fun dan penuh variasi.</li>
        <li>Komunikator, asertif, to the point, ceplas-ceplos, berkarisma, punya interpersonal skill yang baik.</li>
        <li>Baik dalam pemecahan masalah langsung di tempat. Mampu menghadapi masalah, konflik dan kritik.
        Tidak khawatir, menikmati apapun yang terjadi.</li>
        <li>Cenderung untuk menyukai sesuatu yang mekanistis, kegiatan bersama dan olahraga.</li>
        <li>Mudah beradaptasi, toleran, pada umumnya konservatif tentang nilai-nilai. Tidak suka penjelasan terlalu
        panjang. Paling baik dalam hal-hal nyata yang dapat dilakukan.</li>
    </ul>
</div>

<div>
    <h3>Saran Pengembangan</h3>

    <ul>
        <li>Belajarlah memahami perasaan dan pemikiran orang lain terutama saat bicara dengan mereka.</li>
        <li>Belajarlah untuk sabar, menikmati proses, tidak semua hal bisa dicapai dengan cepat.</li>
        <li>Sesekali luangkan waktu untuk merenung dan merencanakan masa depan Anda.</li>
        <li>Cobalah untuk mencatat pengamatan-pengamatan Anda termasuk detailnya.</li>
    </ul>
</div>

<div>
    <h3>Saran Profesi</h3>

    <p>Marketing, Sales, Polisi, Entrepreneur, Pialang Saham, Technical Support</p>
</div>
