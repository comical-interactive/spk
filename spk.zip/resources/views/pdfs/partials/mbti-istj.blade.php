<div>
    <h3>ISTJ (Bertanggungjawab)</h3>

    <ul>
        <li>Serius, tenang, stabil & damai.</li>
        <li>Senang pada fakta, logis, obyektif, praktis & realistis.</li>
        <li>Task oriented, tekun, teratur, menepati janji, dapat diandalkan & bertanggung jawab.</li>
        <li>Pendengar yang baik, setia, hanya mau berbagi dengan orang dekat.</li>
        <li>Memegang aturan, standar & prosedur dengan teguh.</li>
    </ul>
</div>

<div>
    <h3>Saran Pengembangan</h3>

    <ul>
        <li>Belajarlah memahami perasaan & kebutuhan orang lain.</li>
        <li>Kurangi keinginan untuk mengontrol orang lain atau memerintah mereka untuk menegakkan aturan.</li>
        <li>Lihatlah lebih banyak sisi positif pada orang lain atau hal lainnya.</li>
        <li>Terbukalah terhadap perubahan.</li>
    </ul>
</div>

<div>
    <h3>Saran Profesi</h3>

    <p>
        Bidang Manajemen, Polisi, Intelijen, Hakim, Pengacara, Dokter, Akuntan (Staf Keuangan), Programmer
        atau yang berhubungan dengan IT, System Analys, Pemimpin Militer
    </p>
</div>
