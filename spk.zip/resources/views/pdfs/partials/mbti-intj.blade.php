<div>
    <h3>INTJ (Independen)</h3>

    <ul>
        <li>Visioner, punya perencanaan praktis, & biasanya memiliki ide-ide original serta dorongan kuat untuk mencapainya.</li>
        <li>Mandiri dan percaya diri.</li>
        <li>Punya kemampuan analisa yang bagus serta menyederhanakan sesuatu yang rumit dan abstrak menjadi sesuatu
        yang praktis, mudah difahami & dipraktekkan.</li>
        <li>Skeptis, kritis, logis, menentukan (determinatif) dan kadang keras kepala.</li>
        <li>Punya keinginan untuk berkembang serta selalu ingin lebih maju dari orang lain.</li>
        <li>Kritik & konflik tidak menjadi masalah berarti.</li>
    </ul>
</div>

<div>
    <h3>Saran Pengembangan</h3>

    <ul>
        <li>Belajarlah mengungkapkan emosi & perasaan Anda.</li>
        <li>Cobalah untuk lebih terbuka pada dunia luar, banyak bergaul, banyak belajar, banyak membaca, mengunjungi
        banyak tempat, eksplorasi hal baru, & memperluas wawasan.</li>
        <li>Hindari perdebatan tidak penting.</li>
        <li>Belajarlah untuk berempati, memberi perhatian dan lebih peka terhadap orang lain.</li>
    </ul>
</div>

<div>
    <h3>Saran Profesi</h3>

    <p>Peneliti, Ilmuwan, Insinyur, Teknisi, Pengajar, Profesor, Dokter, Research & Development, Business Analyst,
    System Analyst, Pengacara, Hakim, Programmers, Posisi Strategis dalam organisasi.</p>
</div>
