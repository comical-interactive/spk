<div>
    <h3>ISFJ (Setia)</h3>

    <ul>
        <li>Penuh pertimbangan, hati-hati, teliti dan akurat.</li>
        <li>Serius, tenang, stabil namun sensitif.</li>
        <li>Ramah, perhatian pada perasaan & kebutuhan orang lain, setia, kooperatif, pendengar yang baik.</li>
        <li>Punya kemampuan mengorganisasi, detail, teliti, sangat bertanggungjawab & bisa diandalkan.</li>
    </ul>
</div>

<div>
    <h3>Saran Pengembangan</h3>

    <ul>
        <li>Lihat lebih dalam, lebih antusias, & lebih semangat.</li>
        <li>Belajarlah mengatakan AtidakA. Jangan menyenangkan semua orang atau Anda dianggap plin plan.</li>
        <li>Jangan terjebak zona nyaman dan rutinitas. Cobalah hal baru. Ada banyak hal menyenangkan yang mungkin belum
        pernah Anda coba.</li>
    </ul>
</div>

<div>
    <h3>Saran Profesi</h3>

    <p>Architect, Interior Designer, Perawat, Administratif, Designer, Child Care, Konselor, Back Office Manager,
    Penjaga Toko / Perpustakaan, Dunia Perhotelan.</p>
</div>
