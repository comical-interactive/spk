<div>
    <h3>ENFP (Optimis)</h3>

    <ul>
        <li>Ramah, hangat, enerjik, optimis, antusias, semangat tinggi, fun.</li>
        <li>Imaginatif, penuh ide, kreatif, inovatif.</li>
        <li>Mampu beradaptasi dengan beragam situasi dan perubahan.</li>
        <li>Pandai berkomunikasi, senang bersosialisasi & membawa suasana positif.</li>
        <li>Mudah membaca perasaan dan kebutuhan orang lain.</li>
    </ul>
</div>

<div>
    <h3>Saran Pengembangan</h3>

    <ul>
        <li>Belajarlah untuk fokus, disiplin, tegas dan konsisten</li>
        <li>Belajarlah untuk menghadapi konflik dan kritik.</li>
        <li>Pikirkan kebutuhan diri sendiri. Jangan melupakannya karena terlalu peduli pada kebutuhan orang lain.</li>
        <li>Jangan terlalu boros. Belajarlah untuk mengelola keuangan sedikit demi sedikit.</li>
    </ul>
</div>

<div>
    <h3>Saran Profesi</h3>

    <p>Konselor, Psikolog, Entertainer, Pengajar, Motivator, Presenter, Reporter, MC, Seniman, Hospitality</p>
</div>
