<div>
    <h3>ESFP (Murah Hati)</h3>

    <ul>
        <li>Outgoing, easygoing, mudah berteman, bersahabat, sangat sosial, ramah, hangat, & menyenangkan.</li>
        <li>Optimis, ceria, antusias, fun, menghibur, suka menjadi perhatian.</li>
        <li>Punya interpersonal skill yang baik, murah hati, mudah simpatik dan mengenali perasaan orang lain.
        Menghindari konflik dan menjaga keharmonisan suatu hubungan.</li>
        <li>Mengetahui apa yang terjadi di sekelilingnya dan ikut serta dalam kegiatan tersebut.</li>
        <li>Sangat baik dalam keadaan yang membutuhkan common sense, tindakan cepat dan ketrampilan praktis.</li>
    </ul>
</div>

<div>
    <h3>Saran Pengembangan</h3>

    <ul>
        <li>Jangan terburu-buru dalam mengambil keputusan. Belajarlah untuk fokus dan tidak mudah berubah-ubah terutama untuk hal yang penting.</li>
        <li>Jangan menyenangkan semua orang. Begitu pula sebaliknya, tidak semua orang bisa menyenangkan Anda.</li>
        <li>Belajarlah menghadapi kritik dan konflik. Jangan lari.</li>
        <li>nda punya kecenderungan meterialistis. Hati-hati, tidak semua hal bisa diukur dengan materi ataupun uang.</li>
    </ul>
</div>

<div>
    <h3>Saran Profesi</h3>

    <p>Entertainer, Seniman, Marketing, Konselor, Designer, Tour Guide, Bidang Anak-anak, Bidang Hospitality</p>
</div>
