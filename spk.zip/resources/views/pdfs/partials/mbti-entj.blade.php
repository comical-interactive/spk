<div>
    <h3>ENTJ (Pemimpin Alami)</h3>

    <ul>
        <li>Tegas, asertif, to the point, jujur terus terang, obyektif, kritis, & punya standard tinggi.</li>
        <li>Dominan, kuat kemauannya, perfeksionis dan kompetitif.</li>
        <li>Tangguh, disiplin, dan sangat menghargai komitmen.</li>
        <li>Cenderung menutupi perasaan dan menyembunyikan kelemahan.</li>
        <li>Berkarisma, komunikasi baik, mampu menggerakkan orang.</li>
        <li>Berbakat pemimpin.</li>
    </ul>
</div>

<div>
    <h3>Saran Pengembangan</h3>

    <ul>
        <li>Belajarlah untuk relaks. Tidak perlu perfeksionis dan selalu kompetitif dengan semua orang.</li>
        <li>Ungkapkan perasaan Anda. Menyatakan perasaan bukanlah kelemahan.</li>
        <li>Belajarlah mengelola emosi Anda. Jangan mudah marah.</li>
        <li>Belajarlah untuk menghargai dan mengapresiasi orang lain.</li>
        <li>Jangan terlalu arogan dan menganggap remeh orang lain. Lihat sisi positifnya. Jangan hanya melihat benar dan salah saja.</li>
    </ul>
</div>

<div>
    <h3>Saran Profesi</h3>

    <p>Entrepreneur, Pengacara, Hakim, Konsultan, Pemimpin Organisasi, Business Analyst, Bidang Finansial</p>
</div>
