<div>
    <h3>ENFJ (Meyakinkan)</h3>

    <ul>
        <li>Kreatif, imajinatif, peka, sensitive, loyal.</li>
        <li>Pada umumnya peduli pada apa kata orang atau apa yang orang lain inginkan dan cenderung melakukan sesuatu
        dengan memperhatikan perasaan orang lain.</li>
        <li>Pandai bergaul, meyakinkan, ramah, fun, populer, simpatik. Responsif pada kritik dan pujian.</li>
        <li>Menyukai variasi dan tantangan baru.</li>
        <li>Butuh apresiasi dan penerimaan.</li>
    </ul>
</div>

<div>
    <h3>Saran Pengembangan</h3>

    <ul>
        <li>Jangan mengorbankan diri hanya untuk menyenangkan orang lain.</li>
        <li>Jangan mengukur harga diri Anda dari perlakuan orang lain. Jangan mudah kecewa jika mereka tidak seperti yang Anda inginkan.</li>
        <li>Belajarlah untuk tegas dan mengambil keputusan. Menghadapi kritik dan konflik.</li>
        <li>Jangan terlalu bersikap keras terhadap diri sendiri.</li>
    </ul>
</div>

<div>
    <h3>Saran Profesi</h3>

    <p>Konsultan, Psikolog, Konselor, Pengajar, Marketing, HRD, Event Coordinator, Entertainer, Penulis, Motivator</p>
</div>
