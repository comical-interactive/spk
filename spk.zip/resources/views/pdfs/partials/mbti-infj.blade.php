<div>
    <h3>INFJ (Reflektif)</h3>

    <ul>
        <li>Perhatian, empati, sensitif & berkomitmen terhadap sebuah hubungan.</li>
        <li>Sukses karena ketekunan, originalitas dan keinginan kuat untuk melakukan apa saja yang diperlukan termasuk
        memberikan yg terbaik dalam pekerjaan.</li>
        <li>Idealis, perfeksionis, memegang teguh prinsip.</li>
        <li>Visioner, penuh ide, kreatif, suka merenung dan inspiring.</li>
        <li>Biasanya diikuti dan dihormati karena kejelasan visi serta dedikasi pada hal-hal baik.</li>
    </ul>
</div>

<div>
    <h3>Saran Pengembangan</h3>

    <ul>
        <li>Seimbangkan cara pandang Anda. Jangan hanya melihat sisi negatif & resiko. Namun, lihatlah sisi positif dan peluangnya.</li>
        <li>Bersabarlah, jangan mudah marah dan menyalahkan orang lain atau situasi.</li>
        <li>Rileks dan jangan terus menerus berfikir atau menyelesaikan tanggungjawab.</li>
    </ul>
</div>

<div>
    <h3>Saran Profesi</h3>

    <p>Pengajar, Psikolog, Dokter, Konselor, Pekerja Sosial, Fotografer, Seniman, Designer, Child Care.</p>
</div>
