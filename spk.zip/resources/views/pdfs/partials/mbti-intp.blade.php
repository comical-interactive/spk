<div>
    <h3>INTP (Konseptual)</h3>

    <ul>
        <li>Sangat menghargai intelektualitas dan pengetahuan. Menikmati hal-hal teoritis dan ilmiah.
        Senang memecahkan masalah dengan logika dan analisa.</li>
        <li>Diam dan menahan diri. Lebih suka bekerja sendiri.</li>
        <li>Cenderung kritis, skeptis, mudah curiga dan pesimis.</li>
        <li>Tidak suka memimpin dan bisa menjadi pengikut yang tidak banyak menuntut.</li>
        <li>Cenderung memiliki minat yang jelas. Membutuhkan karir dimana minatnya bisa berkembang dan bermanfaat.
        Jika menemukan sesuatu yang menarik minatnya, ia akan sangat serius dan antusias menekuninya.</li>
    </ul>
</div>

<div>
    <h3>Saran Pengembangan</h3>

    <ul>
        <li>Belajarlah membangun hubungan dengan orang lain. Belajar berempati, mendengar aktif, memberi perhatian dan bertukar pendapat.</li>
        <li>Relaks. Jangan terlalu banyak berfikir. Nikmati hidup Anda tanpa harus bertanya mengapa dan bagaimana.</li>
        <li>Cobalah menemukan satu ide, merencanakan dan mewujudkannya. Jangan terlalu sering berganti-ganti ide tetapi tidak satupun yang terwujud.</li>
    </ul>
</div>

<div>
    <h3>Saran Profesi</h3>

    <p>Ilmuwan, Fotografer, Programmer, Ahli komputer, System Analyst, Penulis Buku Teknis, Ahli Forensik, Jaksa, Pengacara, Teknisi</p>
</div>
