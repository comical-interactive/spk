<div>
    <h3>ISFP (Artistik)</h3>

    <ul>
        <li>Berpikiran simpel & praktis, fleksibel, sensitif, ramah, tidak menonjolkan diri, rendah hati pada kemampuannya.</li>
        <li>Menghindari konflik, tidak memaksakan pendapat atau nilai-nilainya pada orang lain.</li>
        <li>Biasanya tidak mau memimpin tetapi menjadi pengikut dan pelaksana yang setia.</li>
        <li>Seringkali santai menyelesaikan sesuatu, karena sangat menikmati apa yang terjadi saat ini.</li>
        <li>Menunjukkan perhatian lebih banyak melalui tindakan dibandingkan kata-kata.</li>
    </ul>
</div>

<div>
    <h3>Saran Pengembangan</h3>

    <ul>
        <li>Jangan takut pada penolakan dan konflik. Anda tidak perlu menyenangkan semua orang.</li>
        <li>Cobalah untuk mulai memikirkan dampak jangka panjang dari keputusan-keputusan kecil di hari ini.</li>
        <li>Asah dan kembangkan sisi kreatifitas dan seni dalam diri Anda sebagai modal bagus dalam diri Anda.</li>
        <li>Cobalah untuk lebih terbuka dan mengekspresikan perasaan Anda.</li>
    </ul>
</div>

<div>
    <h3>Saran Profesi</h3>

    <p>Seniman, Designer, Pekerja Sosial, Konselor, Psikolog, Guru, Aktor, Bidang Hospitality</p>
</div>
