<td class="text-center">
    @if ($grade == 'SK')
      <img src="{{ asset('img/checkmark.png') }}" height="15">
    @endif
  </td>

  <td class="text-center">
    @if ($grade == 'K')
      <img src="{{ asset('img/checkmark.png') }}" height="15">
    @endif
  </td>

  <td class="text-center">
    @if ($grade == 'S')
      <img src="{{ asset('img/checkmark.png') }}" height="15">
    @endif
  </td>

  <td class="text-center">
    @if ($grade == 'B')
      <img src="{{ asset('img/checkmark.png') }}" height="15">
    @endif
  </td>

  <td class="text-center">
    @if ($grade == 'SB')
      <img src="{{ asset('img/checkmark.png') }}" height="15">
    @endif
  </td>
